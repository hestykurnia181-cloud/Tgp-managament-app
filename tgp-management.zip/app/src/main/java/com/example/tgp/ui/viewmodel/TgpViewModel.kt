package com.example.tgp.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.tgp.data.local.AppDatabase
import com.example.tgp.data.model.*
import com.example.tgp.data.repository.CartItem
import com.example.tgp.data.repository.FinancialSummary
import com.example.tgp.data.repository.TgpRepository
import com.example.tgp.data.repository.UserSession
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppScreen {
    SETUP_MASTER,
    LOGIN,
    MASTER_DASHBOARD,
    OWNER_DASHBOARD,
    BUSINESS_HOME,
    POS_MODULE,
    INVENTORY_MODULE,
    TRANSFER_MODULE,
    APPROVAL_MODULE,
    DAMAGED_GOODS_MODULE,
    FINANCE_MODULE,
    ATTENDANCE_MODULE,
    REPORTS_MODULE,
    AUDIT_LOG_VIEWER
}

class TgpViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = TgpRepository(database)

    // App state
    private val _isMasterConfigured = MutableStateFlow<Boolean?>(true)
    val isMasterConfigured: StateFlow<Boolean?> = _isMasterConfigured.asStateFlow()

    private val _currentSession = MutableStateFlow<UserSession?>(null)
    val currentSession: StateFlow<UserSession?> = _currentSession.asStateFlow()

    private val _activeScreen = MutableStateFlow(AppScreen.LOGIN)
    val activeScreen: StateFlow<AppScreen> = _activeScreen.asStateFlow()

    // Strict active_business_id - NO default fallback to businesses[0]
    private val _activeBusinessId = MutableStateFlow<String?>(null)
    val activeBusinessId: StateFlow<String?> = _activeBusinessId.asStateFlow()

    // UI feedback
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // POS Cart
    private val _posCart = MutableStateFlow<List<CartItem>>(emptyList())
    val posCart: StateFlow<List<CartItem>> = _posCart.asStateFlow()

    // Reactive lists
    @OptIn(ExperimentalCoroutinesApi::class)
    val authorizedBusinesses: StateFlow<List<BusinessEntity>> = _currentSession
        .flatMapLatest { session ->
            if (session == null) flowOf(emptyList())
            else repository.getBusinessesForUser(session)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeBusiness: StateFlow<BusinessEntity?> = combine(
        _activeBusinessId,
        authorizedBusinesses
    ) { id, list ->
        if (id == null) null else list.find { it.businessId == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeItems: StateFlow<List<ItemEntity>> = _activeBusinessId
        .flatMapLatest { bId ->
            if (bId == null) flowOf(emptyList())
            else repository.getItemsForBusiness(bId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeTransfers: StateFlow<List<TransferEntity>> = combine(
        _currentSession,
        _activeBusinessId
    ) { session, bId -> Pair(session, bId) }
        .flatMapLatest { (session, bId) ->
            when {
                session == null -> flowOf(emptyList())
                session.user.role == UserRole.OWNER -> repository.getTransfersForOwner(session.user.userId)
                bId != null -> repository.getTransfersForBusiness(bId)
                else -> flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val pendingTransfersForOwner: StateFlow<List<TransferEntity>> = _currentSession
        .flatMapLatest { session ->
            if (session?.user?.role == UserRole.OWNER) {
                repository.getPendingTransfersForOwner(session.user.userId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeDamagedReports: StateFlow<List<DamagedGoodsReportEntity>> = _activeBusinessId
        .flatMapLatest { bId ->
            if (bId == null) flowOf(emptyList())
            else repository.getDamagedGoodsForBusiness(bId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val pendingDamagedForOwner: StateFlow<List<DamagedGoodsReportEntity>> = _currentSession
        .flatMapLatest { session ->
            if (session?.user?.role == UserRole.OWNER) {
                repository.getPendingDamagedGoodsForOwner(session.user.userId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeLedger: StateFlow<List<LedgerTransactionEntity>> = _activeBusinessId
        .flatMapLatest { bId ->
            if (bId == null) flowOf(emptyList())
            else repository.getLedgerForBusiness(bId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val globalOwnerLedger: StateFlow<List<LedgerTransactionEntity>> = combine(
        _currentSession,
        authorizedBusinesses
    ) { session, businesses -> Pair(session, businesses) }
        .flatMapLatest { (session, businesses) ->
            if (session?.user?.role == UserRole.OWNER && businesses.isNotEmpty()) {
                repository.getLedgerForMultipleBusinesses(businesses.map { it.businessId })
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val globalOwnerSales: StateFlow<List<SaleOrderEntity>> = combine(
        _currentSession,
        authorizedBusinesses
    ) { session, businesses -> Pair(session, businesses) }
        .flatMapLatest { (session, businesses) ->
            if (session?.user?.role == UserRole.OWNER && businesses.isNotEmpty()) {
                repository.getSalesForBusinesses(businesses.map { it.businessId })
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val globalOwnerItems: StateFlow<List<ItemEntity>> = combine(
        _currentSession,
        authorizedBusinesses
    ) { session, businesses -> Pair(session, businesses) }
        .flatMapLatest { (session, businesses) ->
            if (session?.user?.role == UserRole.OWNER && businesses.isNotEmpty()) {
                repository.getItemsForBusinesses(businesses.map { it.businessId })
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeAttendances: StateFlow<List<AttendanceEntity>> = _activeBusinessId
        .flatMapLatest { bId ->
            if (bId == null) flowOf(emptyList())
            else repository.getAttendanceForBusiness(bId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOwners: StateFlow<List<UserEntity>> = repository.getAllOwners()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(ExperimentalCoroutinesApi::class)
    val myAdminOwners: StateFlow<List<UserEntity>> = _currentSession
        .flatMapLatest { session ->
            if (session?.user?.role == UserRole.OWNER) {
                repository.getAdminOwners(session.user.userId)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<UserEntity>> = repository.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAuditLogs: StateFlow<List<AuditLogEntity>> = repository.getAllAuditLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        checkMasterStatus()
    }

    fun checkMasterStatus() {
        viewModelScope.launch {
            repository.ensureCanonicalMasterRegistered()
            _isMasterConfigured.value = true
            if (_currentSession.value == null) {
                _activeScreen.value = AppScreen.LOGIN
            }
        }
    }

    fun resetMasterAccount() {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.resetMasterAccount()
            _isLoading.value = false
            result.onSuccess {
                _isMasterConfigured.value = true
                _currentSession.value = null
                _userMessage.value = "Password akun MASTER (mdqputra@gmail.com) telah di-reset ke standar: 990830Ok"
                _activeScreen.value = AppScreen.LOGIN
            }.onFailure {
                _errorMessage.value = "Gagal mereset akun MASTER."
            }
        }
    }

    fun clearMessages() {
        _userMessage.value = null
        _errorMessage.value = null
    }

    fun navigateTo(screen: AppScreen) {
        _activeScreen.value = screen
    }

    // Explicit active business selection (NO first-business fallback)
    fun setActiveBusiness(businessId: String?) {
        _activeBusinessId.value = businessId
        _posCart.value = emptyList() // clear cart on switch
    }

    // -------------------------------------------------------------
    // SETUP & AUTH
    // -------------------------------------------------------------

    fun setupMaster(username: String, pass: String, name: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.setupInitialMaster(username, pass, name)
            _isLoading.value = false
            result.onSuccess { user ->
                _isMasterConfigured.value = true
                _userMessage.value = "Akun MASTER berhasil dikonfigurasi! Silakan login."
                _activeScreen.value = AppScreen.LOGIN
            }.onFailure { err ->
                _errorMessage.value = err.message ?: "Gagal setup MASTER."
            }
        }
    }

    fun login(username: String, pass: String) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.login(username, pass)
            _isLoading.value = false
            result.onSuccess { session ->
                _currentSession.value = session
                _activeBusinessId.value = null // strictly no auto fallback
                _posCart.value = emptyList()

                // Route to appropriate initial role dashboard
                when (session.user.role) {
                    UserRole.MASTER -> _activeScreen.value = AppScreen.MASTER_DASHBOARD
                    UserRole.OWNER -> _activeScreen.value = AppScreen.OWNER_DASHBOARD
                    UserRole.ADMIN_OWNER, UserRole.LEADER, UserRole.STAFF, UserRole.CASHIER -> {
                        _activeScreen.value = AppScreen.BUSINESS_HOME
                    }
                }
                _userMessage.value = "Selamat datang, ${session.user.fullName} (${session.user.role.name})"
            }.onFailure { err ->
                _errorMessage.value = err.message ?: "Login gagal."
            }
        }
    }

    fun quickLoginOwner() {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.quickLoginDemoOwner()
            _isLoading.value = false
            result.onSuccess { session ->
                _currentSession.value = session
                _activeBusinessId.value = null // strictly no auto fallback
                _posCart.value = emptyList()
                _activeScreen.value = AppScreen.OWNER_DASHBOARD
                _userMessage.value = "Selamat datang, ${session.user.fullName} (OWNER)"
            }.onFailure { err ->
                _errorMessage.value = err.message ?: "Gagal masuk demo OWNER."
            }
        }
    }

    fun quickLoginMaster() {
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.quickLoginMaster()
            _isLoading.value = false
            result.onSuccess { session ->
                _currentSession.value = session
                _activeBusinessId.value = null
                _posCart.value = emptyList()
                _activeScreen.value = AppScreen.MASTER_DASHBOARD
                _userMessage.value = "Selamat datang, Master Administrator (${session.user.username})"
            }.onFailure { err ->
                _errorMessage.value = err.message ?: "Gagal masuk MASTER."
            }
        }
    }

    fun logout() {
        _currentSession.value = null
        _activeBusinessId.value = null
        _posCart.value = emptyList()
        _activeScreen.value = AppScreen.LOGIN
        _userMessage.value = "Anda telah logout."
    }

    // -------------------------------------------------------------
    // USER CREATION
    // -------------------------------------------------------------

    fun createOwner(username: String, pass: String, fullName: String) {
        val session = _currentSession.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.createOwner(session.user, username, pass, fullName)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "Akun OWNER '${it.username}' berhasil dibuat."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal membuat OWNER."
            }
        }
    }

    fun createAdminOwner(username: String, pass: String, fullName: String, businessIds: List<String>) {
        val session = _currentSession.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.createAdminOwner(session.user, username, pass, fullName, businessIds)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "ADMIN OWNER '${it.username}' berhasil dibuat dan ditugaskan."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal membuat ADMIN OWNER."
            }
        }
    }

    fun createStaff(businessId: String, username: String, pass: String, fullName: String, role: UserRole) {
        val session = _currentSession.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.createStaffUser(session.user, businessId, username, pass, fullName, role)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "${role.name} '${it.fullName}' berhasil ditambahkan ke Business."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal menambahkan staff."
            }
        }
    }

    // -------------------------------------------------------------
    // BUSINESS CREATION (Strict max 2 modules)
    // -------------------------------------------------------------

    fun createBusiness(name: String, template: BusinessTemplate, modules: List<BusinessModule>) {
        val session = _currentSession.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.createBusiness(session.user, name, template, modules)
            _isLoading.value = false
            res.onSuccess { b ->
                _userMessage.value = "Business '${b.name}' berhasil dibuat dengan modul: ${b.activeModules}."
                // Explicitly set as active business
                _activeBusinessId.value = b.businessId
                _activeScreen.value = AppScreen.BUSINESS_HOME
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal membuat Business."
            }
        }
    }

    // -------------------------------------------------------------
    // ITEM & INVENTORY
    // -------------------------------------------------------------

    fun addItem(
        name: String,
        sku: String,
        category: String,
        type: String,
        costPrice: Double,
        sellingPrice: Double,
        stockQty: Double,
        unit: String,
        location: String,
        recipeBom: String?
    ) {
        val session = _currentSession.value ?: return
        val bId = _activeBusinessId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val item = ItemEntity(
                businessId = bId,
                name = name.trim(),
                sku = sku.trim().ifBlank { "SKU-${System.currentTimeMillis().toString().takeLast(6)}" },
                category = category.trim().ifBlank { "Umum" },
                type = type,
                costPrice = costPrice,
                sellingPrice = sellingPrice,
                stockQuantity = stockQty,
                unit = unit.trim().ifBlank { "pcs" },
                location = location.trim().ifBlank { "Gudang Utama" },
                recipeBom = recipeBom?.trim()?.ifBlank { null }
            )
            val res = repository.createOrUpdateItem(session.user, item)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "Item '${item.name}' berhasil disimpan."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal menyimpan item."
            }
        }
    }

    // -------------------------------------------------------------
    // POS CART & CHECKOUT
    // -------------------------------------------------------------

    fun addToCart(item: ItemEntity) {
        val current = _posCart.value.toMutableList()
        val existingIndex = current.indexOfFirst { it.item.itemId == item.itemId }
        if (existingIndex >= 0) {
            val existing = current[existingIndex]
            if (item.type != "SERVICE" && existing.quantity + 1 > item.stockQuantity) {
                _errorMessage.value = "Stok '${item.name}' tidak mencukupi (Tersedia: ${item.stockQuantity})."
                return
            }
            current[existingIndex] = existing.copy(quantity = existing.quantity + 1)
        } else {
            if (item.type != "SERVICE" && item.stockQuantity < 1) {
                _errorMessage.value = "Stok '${item.name}' habis."
                return
            }
            current.add(CartItem(item, 1.0))
        }
        _posCart.value = current
    }

    fun updateCartQty(itemId: String, qty: Double) {
        val current = _posCart.value.toMutableList()
        val idx = current.indexOfFirst { it.item.itemId == itemId }
        if (idx >= 0) {
            if (qty <= 0) {
                current.removeAt(idx)
            } else {
                val item = current[idx].item
                if (item.type != "SERVICE" && qty > item.stockQuantity) {
                    _errorMessage.value = "Stok maksimal '${item.name}' adalah ${item.stockQuantity}."
                    current[idx] = current[idx].copy(quantity = item.stockQuantity)
                } else {
                    current[idx] = current[idx].copy(quantity = qty)
                }
            }
            _posCart.value = current
        }
    }

    fun removeFromCart(itemId: String) {
        _posCart.value = _posCart.value.filter { it.item.itemId != itemId }
    }

    fun clearCart() {
        _posCart.value = emptyList()
    }

    fun checkoutPos(paymentMethod: PaymentMethod) {
        val session = _currentSession.value ?: return
        val bId = _activeBusinessId.value ?: return
        val cart = _posCart.value
        if (cart.isEmpty()) return

        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.checkoutPos(session.user, bId, cart, paymentMethod)
            _isLoading.value = false
            res.onSuccess { sale ->
                _posCart.value = emptyList()
                _userMessage.value = "Transaksi ${sale.receiptNumber} sukses via ${paymentMethod.name}! Total: Rp ${sale.totalAmount.toLong()}"
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal memproses transaksi kasir."
            }
        }
    }

    // -------------------------------------------------------------
    // TRANSFERS (Atomic, Same Owner Only)
    // -------------------------------------------------------------

    fun requestTransfer(sourceBusinessId: String, destBusinessId: String, itemId: String, qty: Double, notes: String) {
        val session = _currentSession.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.createTransferRequest(session.user, sourceBusinessId, destBusinessId, itemId, qty, notes)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "Permintaan transfer ${it.transferReference} berhasil dibuat (Status: PENDING)."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal membuat transfer."
            }
        }
    }

    fun approveTransfer(transferId: String) {
        val session = _currentSession.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.approveTransfer(session.user, transferId)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "TRANSFER BERHASIL DISETUJUI & DIPROSES SECARA ATOMIC (Stok & Ledger terupdate)."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal menyetujui transfer."
            }
        }
    }

    fun rejectTransfer(transferId: String, reason: String) {
        val session = _currentSession.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.rejectTransfer(session.user, transferId, reason)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "Transfer ditolak. Stok dan Ledger tidak berubah."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal menolak transfer."
            }
        }
    }

    // -------------------------------------------------------------
    // DAMAGED GOODS
    // -------------------------------------------------------------

    fun reportDamagedGoods(location: String, itemId: String, quantity: Double, reason: String) {
        val session = _currentSession.value ?: return
        val bId = _activeBusinessId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.createDamagedGoodsReport(session.user, bId, location, itemId, quantity, reason)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "Laporan barang rusak berhasil dikirim (Status: PENDING Approval)."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal mengirim laporan."
            }
        }
    }

    fun approveDamagedGoods(reportId: String) {
        val session = _currentSession.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.approveDamagedGoodsReport(session.user, reportId)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "Laporan barang rusak disetujui. Stok dipotong & ledger kerugian dicatat."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal menyetujui laporan."
            }
        }
    }

    fun rejectDamagedGoods(reportId: String) {
        val session = _currentSession.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.rejectDamagedGoodsReport(session.user, reportId)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "Laporan barang rusak ditolak."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal menolak laporan."
            }
        }
    }

    // -------------------------------------------------------------
    // FINANCE & MANUAL LEDGER
    // -------------------------------------------------------------

    fun addManualLedgerEntry(type: LedgerType, category: String, amount: Double, desc: String) {
        val session = _currentSession.value ?: return
        val bId = _activeBusinessId.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val res = repository.addManualLedgerEntry(session.user, bId, type, category, amount, desc)
            _isLoading.value = false
            res.onSuccess {
                _userMessage.value = "Transaksi pembukuan ${type.name} berhasil dicatat."
            }.onFailure {
                _errorMessage.value = it.message ?: "Gagal mencatat transaksi."
            }
        }
    }

    // -------------------------------------------------------------
    // ATTENDANCE
    // -------------------------------------------------------------

    fun recordAttendance(type: String, note: String) {
        val session = _currentSession.value ?: return
        val bId = _activeBusinessId.value ?: return
        viewModelScope.launch {
            val res = repository.recordAttendance(session.user, bId, type, note)
            res.onSuccess {
                _userMessage.value = "Absensi $type berhasil dicatat."
            }
        }
    }
}
