package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tgp.data.model.UserRole
import com.example.tgp.ui.components.TgpBottomBar
import com.example.tgp.ui.components.TgpTopBar
import com.example.tgp.ui.screens.*
import com.example.tgp.ui.viewmodel.AppScreen
import com.example.tgp.ui.viewmodel.TgpViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: TgpViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                TgpMainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun TgpMainApp(viewModel: TgpViewModel) {
    val isMasterConfigured by viewModel.isMasterConfigured.collectAsState()
    val session by viewModel.currentSession.collectAsState()
    val activeScreen by viewModel.activeScreen.collectAsState()
    val activeBusiness by viewModel.activeBusiness.collectAsState()
    val authorizedBusinesses by viewModel.authorizedBusinesses.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var showSwitchBizDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessages()
        }
    }

    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessages()
        }
    }

    // Handle Android system back button
    BackHandler(enabled = session != null && activeScreen != AppScreen.BUSINESS_HOME && activeScreen != AppScreen.OWNER_DASHBOARD && activeScreen != AppScreen.MASTER_DASHBOARD) {
        when (session?.user?.role) {
            UserRole.MASTER -> viewModel.navigateTo(AppScreen.MASTER_DASHBOARD)
            UserRole.OWNER -> viewModel.navigateTo(AppScreen.OWNER_DASHBOARD)
            else -> viewModel.navigateTo(AppScreen.BUSINESS_HOME)
        }
    }

    // Initial Master Setup screen
    if (isMasterConfigured == false) {
        SetupMasterScreen(viewModel = viewModel)
        return
    }

    // Login screen when unauthenticated
    if (session == null) {
        LoginScreen(viewModel = viewModel)
        return
    }

    val currentRole = session!!.user.role

    Scaffold(
        topBar = {
            val showBackButton = activeScreen != AppScreen.BUSINESS_HOME &&
                    activeScreen != AppScreen.OWNER_DASHBOARD &&
                    activeScreen != AppScreen.MASTER_DASHBOARD

            val screenTitle = when (activeScreen) {
                AppScreen.MASTER_DASHBOARD -> "Platform Controller"
                AppScreen.OWNER_DASHBOARD -> "Multi-Business Dashboard"
                AppScreen.BUSINESS_HOME -> activeBusiness?.name ?: "Pilih Bisnis"
                AppScreen.POS_MODULE -> "Kasir POS"
                AppScreen.INVENTORY_MODULE -> "Inventaris & Stok"
                AppScreen.TRANSFER_MODULE -> "Transfer Antar Bisnis"
                AppScreen.APPROVAL_MODULE -> "Pusat Approval"
                AppScreen.DAMAGED_GOODS_MODULE -> "Laporan Barang Rusak"
                AppScreen.FINANCE_MODULE -> "Pembukuan & Kas"
                AppScreen.ATTENDANCE_MODULE -> "Presensi Staff"
                AppScreen.AUDIT_LOG_VIEWER -> "Audit Keamanan"
                AppScreen.REPORTS_MODULE -> "Laporan & Rekap"
                else -> null
            }

            TgpTopBar(
                session = session,
                activeBusiness = activeBusiness,
                title = screenTitle,
                onSwitchBusinessClick = { showSwitchBizDialog = true },
                onLogoutClick = { viewModel.logout() },
                onBackClick = if (showBackButton) {
                    {
                        when (currentRole) {
                            UserRole.MASTER -> viewModel.navigateTo(AppScreen.MASTER_DASHBOARD)
                            UserRole.OWNER -> viewModel.navigateTo(AppScreen.OWNER_DASHBOARD)
                            else -> viewModel.navigateTo(AppScreen.BUSINESS_HOME)
                        }
                    }
                } else null
            )
        },
        bottomBar = {
            TgpBottomBar(
                role = currentRole,
                activeBusiness = activeBusiness,
                currentScreen = activeScreen,
                onNavigate = { viewModel.navigateTo(it) }
            )
        },
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.padding(16.dp)
            ) { data ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.inverseSurface)
                ) {
                    Text(
                        text = data.visuals.message,
                        color = MaterialTheme.colorScheme.inverseOnSurface,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = activeScreen,
                label = "ScreenTransition"
            ) { target ->
                when (target) {
                    AppScreen.MASTER_DASHBOARD -> MasterDashboardScreen(viewModel = viewModel)
                    AppScreen.OWNER_DASHBOARD -> OwnerDashboardScreen(viewModel = viewModel)
                    AppScreen.BUSINESS_HOME -> BusinessHomeScreen(
                        viewModel = viewModel,
                        onOpenSwitchBusiness = { showSwitchBizDialog = true }
                    )
                    AppScreen.POS_MODULE -> PosScreen(viewModel = viewModel)
                    AppScreen.INVENTORY_MODULE -> InventoryScreen(viewModel = viewModel)
                    AppScreen.TRANSFER_MODULE -> TransferScreen(viewModel = viewModel)
                    AppScreen.APPROVAL_MODULE -> ApprovalScreen(viewModel = viewModel)
                    AppScreen.DAMAGED_GOODS_MODULE -> DamagedGoodsScreen(viewModel = viewModel)
                    AppScreen.FINANCE_MODULE -> FinanceScreen(viewModel = viewModel)
                    AppScreen.ATTENDANCE_MODULE -> AttendanceScreen(viewModel = viewModel)
                    AppScreen.AUDIT_LOG_VIEWER, AppScreen.REPORTS_MODULE -> AuditLogViewerScreen(viewModel = viewModel)
                    else -> BusinessHomeScreen(
                        viewModel = viewModel,
                        onOpenSwitchBusiness = { showSwitchBizDialog = true }
                    )
                }
            }
        }
    }

    if (showSwitchBizDialog) {
        SwitchBusinessDialog(
            businesses = authorizedBusinesses,
            activeBusinessId = activeBusiness?.businessId,
            onDismiss = { showSwitchBizDialog = false },
            onSelectBusiness = { selected ->
                viewModel.setActiveBusiness(selected.businessId)
                viewModel.navigateTo(AppScreen.BUSINESS_HOME)
            }
        )
    }
}
